from src.ats_scorer import ATSScore
from src.gap_analyzer import analyze_gaps


def test_required_gaps_are_high_priority():
    score = ATSScore(
        required_score=35,
        preferred_score=0,
        overall_score=50,
        matched_required=["Python"],
        missing_required=["SQL"],
        matched_preferred=[],
        missing_preferred=[],
    )

    gaps = analyze_gaps(score)

    assert len(gaps) == 1
    assert gaps[0].requirement == "SQL"
    assert gaps[0].priority == "HIGH"