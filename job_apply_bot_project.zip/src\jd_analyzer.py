from __future__ import annotations

from dataclasses import dataclass, field
import re


@dataclass
class JDAnalysis:
    """
    Structured analysis of a job description.

    The analyzer is intentionally conservative:
    it extracts requirements from the supplied text without
    inventing qualifications or experience.
    """

    required: list[str] = field(default_factory=list)
    preferred: list[str] = field(default_factory=list)
    implicit: list[str] = field(default_factory=list)


def _clean_items(items: list[str]) -> list[str]:
    """Normalize and deduplicate extracted requirement strings."""

    cleaned = []
    seen = set()

    for item in items:
        item = re.sub(r"\s+", " ", item).strip(" .,:;-")

        if not item:
            continue

        key = item.lower()

        if key not in seen:
            seen.add(key)
            cleaned.append(item)

    return cleaned


def _extract_bullets(text: str) -> list[str]:
    """Extract bullet-style requirements from a job description."""

    results = []

    for line in text.splitlines():
        line = line.strip()

        if not line:
            continue

        match = re.match(r"^(?:[-*•]|\d+[.)])\s*(.+)$", line)

        if match:
            results.append(match.group(1).strip())

    return results


def extract_requirements(job_description: str) -> JDAnalysis:
    """
    Analyze a job description and return structured requirements.

    Required items are identified primarily from sections such as:
    Requirements, Required Qualifications, Must Have, and similar.

    Preferred items are identified from sections such as:
    Preferred, Preferred Qualifications, Nice to Have, and similar.

    If the description does not contain explicit sections, bullet
    points are treated conservatively as required items.
    """

    if not isinstance(job_description, str):
        raise TypeError("job_description must be a string.")

    text = job_description.strip()

    if not text:
        raise ValueError("job_description cannot be empty.")

    lines = text.splitlines()

    required = []
    preferred = []
    implicit = []

    section = None

    required_headers = {
        "requirements",
        "required",
        "required qualifications",
        "required skills",
        "minimum qualifications",
        "must have",
        "qualifications",
    }

    preferred_headers = {
        "preferred",
        "preferred qualifications",
        "preferred skills",
        "nice to have",
        "nice-to-have",
        "bonus",
        "desired qualifications",
    }

    for raw_line in lines:
        line = raw_line.strip()

        if not line:
            continue

        normalized = re.sub(
            r"^[#>*\-\d.)\s]+",
            "",
            line,
        ).strip().lower().rstrip(":")

        if normalized in required_headers:
            section = "required"
            continue

        if normalized in preferred_headers:
            section = "preferred"
            continue

        # Detect common heading patterns.
        if any(
            phrase in normalized
            for phrase in (
                "required qualifications",
                "required skills",
                "minimum qualifications",
                "requirements",
            )
        ):
            section = "required"
            continue

        if any(
            phrase in normalized
            for phrase in (
                "preferred qualifications",
                "preferred skills",
                "nice to have",
                "nice-to-have",
            )
        ):
            section = "preferred"
            continue

        bullet_match = re.match(
            r"^(?:[-*•]|\d+[.)])\s*(.+)$",
            line,
        )

        if bullet_match:
            item = bullet_match.group(1).strip()

            if section == "preferred":
                preferred.append(item)
            elif section == "required":
                required.append(item)
            else:
                required.append(item)

    # Extract common inline qualification patterns.
    qualification_patterns = [
        r"\b\d+\+?\s+years?\s+(?:of\s+)?experience\b",
        r"\b[A-Za-z]+/[A-Za-z]+\b",
        r"\bHTML/CSS\b",
        r"\bAdobe Creative Suite\b",
    ]

    for pattern in qualification_patterns:
        for match in re.finditer(
            pattern,
            text,
            flags=re.IGNORECASE,
        ):
            value = match.group(0).strip()

            if value.lower() not in {
                item.lower() for item in required
            } and value.lower() not in {
                item.lower() for item in preferred
            }:
                implicit.append(value)

    return JDAnalysis(
        required=_clean_items(required),
        preferred=_clean_items(preferred),
        implicit=_clean_items(implicit),
    )


def analyze_job_description(job_description: str) -> JDAnalysis:
    """
    Backward/alternate API for callers that prefer an explicit
    analyzer function name.
    """

    return extract_requirements(job_description)


def analyze_jd(job_description: str) -> JDAnalysis:
    """Compatibility alias."""

    return extract_requirements(job_description)

def print_analysis(analysis: JDAnalysis) -> None:
    """
    Print a human-readable job-description analysis.

    Kept as a separate function so the resume-generation pipeline
    can display the analysis without changing the analysis object.
    """

    if not isinstance(analysis, JDAnalysis):
        raise TypeError("analysis must be a JDAnalysis.")

    print("========== JD ANALYSIS ==========")

    print("Required:")

    if analysis.required:
        for item in analysis.required:
            print(f"- {item}")
    else:
        print("- None")

    print("Preferred:")

    if analysis.preferred:
        for item in analysis.preferred:
            print(f"- {item}")
    else:
        print("- None")

    print("Implicit:")

    if analysis.implicit:
        for item in analysis.implicit:
            print(f"- {item}")
    else:
        print("- None")

    print("=================================")