from __future__ import annotations

from dataclasses import dataclass

from src.ats_scorer import ATSScore


@dataclass
class SkillGap:
    requirement: str
    category: str
    priority: str
    recommendation: str


def analyze_gaps(
    ats_score: ATSScore,
    requirement_categories: dict[str, str] | None = None,
) -> list[SkillGap]:

    requirement_categories = requirement_categories or {}

    gaps: list[SkillGap] = []

    for requirement in ats_score.missing_required:
        category = requirement_categories.get(
            requirement.lower(),
            "requirement",
        )

        gaps.append(
            SkillGap(
                requirement=requirement,
                category=category,
                priority="HIGH",
                recommendation=(
                    f"Look for existing resume evidence related to "
                    f"'{requirement}'. Do not invent experience."
                ),
            )
        )

    for requirement in ats_score.missing_preferred:
        category = requirement_categories.get(
            requirement.lower(),
            "requirement",
        )

        gaps.append(
            SkillGap(
                requirement=requirement,
                category=category,
                priority="MEDIUM",
                recommendation=(
                    f"Consider emphasizing existing evidence related to "
                    f"'{requirement}' if supported."
                ),
            )
        )

    return gaps