from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable


@dataclass
class ATSScore:
    required_score: float = 0.0
    preferred_score: float = 0.0
    overall_score: float = 0.0
    matched: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)

    # Compatibility fields used by the existing resume pipeline
    required_coverage: float = 0.0
    preferred_coverage: float = 0.0
    overall_coverage: float = 0.0
    required_total: int = 0
    required_matched: int = 0
    preferred_total: int = 0
    preferred_matched: int = 0


def _is_supported(match) -> bool:
    """
    Accept the different evidence-match representations
    used in the project.
    """
    if isinstance(match, bool):
        return match

    if hasattr(match, "supported"):
        return bool(match.supported)

    if isinstance(match, dict):
        return bool(
            match.get("supported", match.get("matched", False))
        )

    if hasattr(match, "evidence"):
        return bool(match.evidence)

    return False


def _requirement_name(match) -> str:
    """
    Extract the requirement name from an EvidenceMatch,
    dictionary, or string.
    """
    if isinstance(match, str):
        return match

    if hasattr(match, "requirement"):
        return str(match.requirement)

    if isinstance(match, dict):
        return str(
            match.get(
                "requirement",
                match.get("term", match.get("keyword", "")),
            )
        )

    return str(match)


def calculate_ats_score(
    required_matches=None,
    preferred_matches=None,
    required_keywords=None,
    preferred_keywords=None,
) -> ATSScore:
    """
    Calculate ATS coverage from either:

    1. Evidence matches:
       calculate_ats_score(
           required_matches=[...],
           preferred_matches=[...]
       )

    2. Keyword lists:
       calculate_ats_score(
           required_keywords=[...],
           preferred_keywords=[...]
       )
    """

    # ---------------------------------------------------------
    # Evidence-match mode
    # ---------------------------------------------------------
    if required_matches is not None or preferred_matches is not None:

        required_matches = list(required_matches or [])
        preferred_matches = list(preferred_matches or [])

        required_total = len(required_matches)
        preferred_total = len(preferred_matches)

        required_supported = [
            match
            for match in required_matches
            if _is_supported(match)
        ]

        preferred_supported = [
            match
            for match in preferred_matches
            if _is_supported(match)
        ]

        required_matched = len(required_supported)
        preferred_matched = len(preferred_supported)

        required_score = (
            required_matched / required_total * 100
            if required_total
            else 100.0
        )

        preferred_score = (
            preferred_matched / preferred_total * 100
            if preferred_total
            else 100.0
        )

        # Required requirements receive more weight.
        if required_total and preferred_total:
            overall_score = (
                required_score * 0.7
                + preferred_score * 0.3
            )
        elif required_total:
            overall_score = required_score
        elif preferred_total:
            overall_score = preferred_score
        else:
            overall_score = 100.0

        matched = [
            _requirement_name(match)
            for match in required_supported + preferred_supported
        ]

        missing = [
            _requirement_name(match)
            for match in required_matches + preferred_matches
            if not _is_supported(match)
        ]

        return ATSScore(
            required_score=required_score,
            preferred_score=preferred_score,
            overall_score=overall_score,
            matched=matched,
            missing=missing,
            required_coverage=required_score,
            preferred_coverage=preferred_score,
            overall_coverage=overall_score,
            required_total=required_total,
            required_matched=required_matched,
            preferred_total=preferred_total,
            preferred_matched=preferred_matched,
        )

    # ---------------------------------------------------------
    # Keyword mode
    # ---------------------------------------------------------
    required_keywords = list(required_keywords or [])
    preferred_keywords = list(preferred_keywords or [])

    raise ValueError(
        "calculate_ats_score requires either "
        "required_matches/preferred_matches or keyword inputs."
    )


def score_keyword_coverage(
    resume_text: str,
    required_keywords: Iterable[str],
    preferred_keywords: Iterable[str],
) -> ATSScore:
    """
    Score keyword coverage directly against resume text.
    """

    text = str(resume_text or "").lower()

    required_keywords = list(required_keywords or [])
    preferred_keywords = list(preferred_keywords or [])

    required_matched = [
        keyword
        for keyword in required_keywords
        if str(keyword).lower() in text
    ]

    preferred_matched = [
        keyword
        for keyword in preferred_keywords
        if str(keyword).lower() in text
    ]

    required_missing = [
        keyword
        for keyword in required_keywords
        if str(keyword).lower() not in text
    ]

    preferred_missing = [
        keyword
        for keyword in preferred_keywords
        if str(keyword).lower() not in text
    ]

    required_total = len(required_keywords)
    preferred_total = len(preferred_keywords)

    required_score = (
        len(required_matched) / required_total * 100
        if required_total
        else 100.0
    )

    preferred_score = (
        len(preferred_matched) / preferred_total * 100
        if preferred_total
        else 100.0
    )

    if required_total and preferred_total:
        overall_score = (
            required_score * 0.7
            + preferred_score * 0.3
        )
    elif required_total:
        overall_score = required_score
    elif preferred_total:
        overall_score = preferred_score
    else:
        overall_score = 100.0

    return ATSScore(
        required_score=required_score,
        preferred_score=preferred_score,
        overall_score=overall_score,
        matched=required_matched + preferred_matched,
        missing=required_missing + preferred_missing,
        required_coverage=required_score,
        preferred_coverage=preferred_score,
        overall_coverage=overall_score,
        required_total=required_total,
        required_matched=len(required_matched),
        preferred_total=preferred_total,
        preferred_matched=len(preferred_matched),
    )


def score_resume(
    resume_text: str,
    required_keywords=None,
    preferred_keywords=None,
) -> ATSScore:
    """
    Backward-compatible alias for score_keyword_coverage().
    """
    return score_keyword_coverage(
        resume_text,
        required_keywords or [],
        preferred_keywords or [],
    )


def print_ats_score(score: ATSScore) -> None:
    """
    Print ATS score in the format expected by the resume pipeline.
    """

    print("========== ATS SCORE ==========")
    print(
        f"Required coverage: "
        f"{score.required_score:.2f}%"
    )
    print(
        f"Preferred coverage: "
        f"{score.preferred_score:.2f}%"
    )
    print(
        f"Overall coverage: "
        f"{score.overall_score:.2f}%"
    )

    print("Matched:")
    for item in score.matched:
        print(f"- {item}")

    print("Missing:")
    for item in score.missing:
        print(f"- {item}")

    print("================================")