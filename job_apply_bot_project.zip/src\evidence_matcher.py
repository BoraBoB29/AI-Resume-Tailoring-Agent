from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable


@dataclass
class EvidenceMatch:
    requirement: str
    supported: bool
    evidence: list[str] = field(default_factory=list)


def _normalize(text: str) -> str:
    return " ".join(str(text).lower().split())


def _candidate_text(candidate) -> str:
    """
    Convert the candidate/master resume object into searchable text.
    Supports strings, dictionaries, and common resume object structures.
    """
    if candidate is None:
        return ""

    if isinstance(candidate, str):
        return candidate

    if isinstance(candidate, dict):
        parts = []

        def collect(value):
            if isinstance(value, str):
                parts.append(value)
            elif isinstance(value, dict):
                for v in value.values():
                    collect(v)
            elif isinstance(value, (list, tuple, set)):
                for v in value:
                    collect(v)

        collect(candidate)
        return "\n".join(parts)

    # Dataclass/object support
    parts = []

    for attr in (
        "summary",
        "profile",
        "skills",
        "experience",
        "education",
        "projects",
        "certifications",
        "achievements",
    ):
        if hasattr(candidate, attr):
            value = getattr(candidate, attr)
            if isinstance(value, str):
                parts.append(value)
            elif isinstance(value, (list, tuple)):
                parts.extend(str(x) for x in value)
            elif value is not None:
                parts.append(str(value))

    return "\n".join(parts)


def find_evidence(
    requirement: str,
    candidate,
) -> list[str]:
    """
    Find resume text that provides direct lexical evidence
    for a requirement.

    This function is intentionally conservative and does not
    invent qualifications.
    """
    if not requirement:
        return []

    text = _candidate_text(candidate)

    if not text.strip():
        return []

    requirement_normalized = _normalize(requirement)

    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip()
    ]

    evidence = []

    # Direct phrase match
    if requirement_normalized in _normalize(text):
        for line in lines:
            if requirement_normalized in _normalize(line):
                evidence.append(line)

    # Word-level fallback
    if not evidence:
        words = [
            word
            for word in requirement_normalized.split()
            if len(word) > 2
        ]

        if words:
            for line in lines:
                normalized_line = _normalize(line)

                if all(word in normalized_line for word in words):
                    evidence.append(line)

    return list(dict.fromkeys(evidence))


def supported_requirements(
    requirements: Iterable[str],
    candidate,
) -> list[str]:
    """
    Return requirements for which the candidate has
    explicit supporting evidence.
    """
    supported = []

    for requirement in requirements or []:
        if find_evidence(requirement, candidate):
            supported.append(requirement)

    return supported


def match_evidence(
    requirements: Iterable[str],
    candidate,
) -> list[EvidenceMatch]:
    """
    Match each requirement against candidate evidence.
    """
    results = []

    for requirement in requirements or []:
        evidence = find_evidence(requirement, candidate)

        results.append(
            EvidenceMatch(
                requirement=requirement,
                supported=bool(evidence),
                evidence=evidence,
            )
        )

    return results


def match_requirements(
    requirements: Iterable[str],
    candidate,
) -> list[EvidenceMatch]:
    """
    Compatibility API used by jd_intelligence.py.

    This is an alias-style wrapper around match_evidence().
    """
    return match_evidence(requirements, candidate)


def unsupported_requirements(
    requirements: Iterable[str],
    candidate,
) -> list[str]:
    """
    Return requirements for which no explicit evidence exists.
    """
    return [
        requirement
        for requirement in requirements or []
        if not find_evidence(requirement, candidate)
    ]